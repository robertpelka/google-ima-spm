========================================
Google Interactive Media Ads SDK for tvOS
========================================

This is the Google Interactive Media Ads SDK for tvOS.

Requirements:
- Xcode 7.2 or later.
- tvOS deployment target of tvOS 9.1 or later.

The latest documentation and code samples are available at:
https://developers.google.com/interactive-media-ads/
